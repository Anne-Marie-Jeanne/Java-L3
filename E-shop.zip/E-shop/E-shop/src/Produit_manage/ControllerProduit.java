package Produit_manage;

import DAO.ProduitBD;
import Modele.Categorie;
import Modele.Produit;
import Modele.User;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import tools.Outil;

public class ControllerProduit {

    @FXML
    private TextField Produit_name_txt;
    @FXML
    private Button precedent_prod;

    @FXML
    private TextField quantite_txt;

    @FXML
    private TextField PU_txt;

    @FXML
    private Button Ajout_btn;

    @FXML
    private TableView<Produit> prodTable_view;

    @FXML
    private TableColumn<Produit, Integer> idProd_col;

    @FXML
    private TableColumn<Categorie, String> idCat_col;

    @FXML
    private TableColumn<Produit, String> NomProd_col;

    @FXML
    private TableColumn<Produit, Integer> Quantite_col;

    @FXML
    private TableColumn<Produit, Integer> PU_col;

    @FXML
    private Label param_us;

    @FXML
    private Button modif_btn;

    @FXML
    private Button supprimer_btn;

    @FXML
    private ComboBox<String> choice_cat;

    @FXML
    void ajouter(ActionEvent event) {
        String nomcat = choice_cat.getValue();
        String libelle = Produit_name_txt.getText();
        int qte = Produit_name_txt.getAnchor();
        int pu = PU_txt.getAnchor();
     
        if (nomcat.trim().equals("")){
            Outil.showErrorMessage("Erreur !", "Entrez un nom de produit s'il-vous plaît.");
        }else{
            ProduitBD ic = new ProduitBD();
            Produit p = new Produit();
            p.setLibProd(nomcat);
            if(ic.AjouterProd(p) == true){
                Outil.showConfirmationMessage("Félicitations !", "Le produit été ajouté avec succès.");
                loadTableProd();
                choice_cat.setValue("");
            }else{
                Outil.showErrorMessage("Erreur", "Les données saisies n'ont pas été ajoutées !");
            }
        }
    }

    @FXML
    void modifier(ActionEvent event) {

    }

    @FXML
    void supprimerProd(ActionEvent event) {

    }
    
    @FXML
    void retourProd(ActionEvent event) throws IOException {
        String url = "/accueil_general/Accueil.fxml";
        Outil.load(event, url);
    }
    
    public void initialize() {
        ProduitBD prodCat = new ProduitBD();
        List<String> lProdCat = prodCat.getCategorietbyIdCat();
        choice_cat.setItems(FXCollections.observableArrayList(lProdCat));
    }
    
    public void initialize(URL location, ResourceBundle resources) {
        //Chaque colone correspond a un attribut de la classe Categorie
        idProd_col.setCellValueFactory(new PropertyValueFactory<>("idprod"));
        idCat_col.setCellValueFactory(new PropertyValueFactory<>("idCat"));
        NomProd_col.setCellValueFactory(new PropertyValueFactory<>("libProd"));
        Quantite_col.setCellValueFactory(new PropertyValueFactory<>("Qte"));
        PU_col.setCellValueFactory(new PropertyValueFactory<>("Prix"));
        loadTableProd();
        
        
    }
  
    private void loadTableProd(){
        ProduitBD ic = new ProduitBD();
        ObservableList<Produit> l_produit = FXCollections.observableArrayList();
        ic.Consulter().stream()
                .forEach(c->l_produit.add(c));
        //Chargement des categories dans le tableau
        prodTable_view.setItems(l_produit);
    }
}
